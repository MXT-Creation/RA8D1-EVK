#pragma once

void board_init(void);
