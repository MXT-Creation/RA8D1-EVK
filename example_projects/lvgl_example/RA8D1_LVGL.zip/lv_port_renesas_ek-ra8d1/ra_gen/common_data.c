/* generated common source file - do not edit */
#include "common_data.h"
icu_instance_ctrl_t g_external_irq13_ctrl;

/** External IRQ extended configuration for ICU HAL driver */
const icu_extended_cfg_t g_external_irq13_ext_cfg =
{ .filter_src = EXTERNAL_IRQ_DIGITAL_FILTER_PCLK_DIV, };

const external_irq_cfg_t g_external_irq13_cfg =
{ .channel = 13, .trigger = EXTERNAL_IRQ_TRIG_FALLING, .filter_enable = true, .clock_source_div =
          EXTERNAL_IRQ_CLOCK_SOURCE_DIV_64,
  .p_callback = touch_irq_callback,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = &NULL,
#endif
  .p_extend = (void*) &g_external_irq13_ext_cfg,
  .ipl = (12),
#if defined(VECTOR_NUMBER_ICU_IRQ13)
    .irq                 = VECTOR_NUMBER_ICU_IRQ13,
#else
  .irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const external_irq_instance_t g_external_irq13 =
{ .p_ctrl = &g_external_irq13_ctrl, .p_cfg = &g_external_irq13_cfg, .p_api = &g_external_irq_on_icu };
const uint8_t DRW_INT_IPL = (2);
d2_device *d2_handle0;
/* MIPI PHY Macros */
#define MIPI_PHY_CLKSTPT   (1183)
#define MIPI_PHY_CLKBFHT   (10 + 1)
#define MIPI_PHY_CLKKPT    (22 + 4)
#define MIPI_PHY_GOLPBKT   (40)

#define MIPI_PHY_TINIT     (71999)
#define MIPI_PHY_TCLKPREP  (8)
#define MIPI_PHY_THSPREP   (5)
#define MIPI_PHY_TCLKTRAIL (7)
#define MIPI_PHY_TCLKPOST  (19)
#define MIPI_PHY_TCLKPRE   (1)
#define MIPI_PHY_TCLKZERO  (27)
#define MIPI_PHY_THSEXIT   (11)
#define MIPI_PHY_THSTRAIL  (8)
#define MIPI_PHY_THSZERO   (19)
#define MIPI_PHY_TLPEXIT   (7)

/* MIPI PHY Structures */
const mipi_phy_timing_t g_mipi_phy0_timing =
{ .t_init = 0x3FFFF & (uint32_t)MIPI_PHY_TINIT,
  .t_clk_prep = (uint8_t)MIPI_PHY_TCLKPREP,
  .t_hs_prep = (uint8_t)MIPI_PHY_THSPREP,
  .dphytim4_b.t_clk_trail = (uint32_t)MIPI_PHY_TCLKTRAIL,
  .dphytim4_b.t_clk_post = (uint32_t)MIPI_PHY_TCLKPOST,
  .dphytim4_b.t_clk_pre = (uint32_t)MIPI_PHY_TCLKPRE,
  .dphytim4_b.t_clk_zero = (uint32_t)MIPI_PHY_TCLKZERO,
  .dphytim5_b.t_hs_exit = (uint32_t)MIPI_PHY_THSEXIT,
  .dphytim5_b.t_hs_trail = (uint32_t)MIPI_PHY_THSTRAIL,
  .dphytim5_b.t_hs_zero = (uint32_t)MIPI_PHY_THSZERO,
  .t_lp_exit = (uint32_t)MIPI_PHY_TLPEXIT, };

mipi_phy_ctrl_t g_mipi_phy0_ctrl;
const mipi_phy_cfg_t g_mipi_phy0_cfg =
{ .pll_settings = /* Calculated MIPI PHY PLL frequency: 1000000000 Hz (error 0.00%) = 24000000 Hz / 3 * 125.00 */
{ .div = 3 - 1, .mul_int = 125 - 1, .mul_frac = 0 /* Value: 0 */},
  .lp_divisor = 5 - 1, .p_timing = &g_mipi_phy0_timing, };
/* Instance structure to use this module. */
const mipi_phy_instance_t g_mipi_phy0 =
{ .p_ctrl = &g_mipi_phy0_ctrl, .p_cfg = &g_mipi_phy0_cfg, .p_api = &g_mipi_phy };
mipi_dsi_instance_ctrl_t g_mipi_dsi0_ctrl;

const mipi_dsi_timing_t g_mipi_dsi0_timing =
{ .clock_stop_time = MIPI_PHY_CLKSTPT,
  .clock_beforehand_time = MIPI_PHY_CLKBFHT,
  .clock_keep_time = MIPI_PHY_CLKKPT,
  .go_lp_and_back = MIPI_PHY_GOLPBKT, };

const mipi_dsi_extended_cfg_t g_mipi_dsi0_extended_cfg =
{ .dsi_seq0.ipl = (12), .dsi_seq0.irq = VECTOR_NUMBER_MIPIDSI_SEQ0,

.dsi_seq1.ipl = (12),
  .dsi_seq1.irq = VECTOR_NUMBER_MIPIDSI_SEQ1,

  .dsi_vin1.ipl = (12),
  .dsi_vin1.irq = VECTOR_NUMBER_MIPIDSI_VIN1,

  .dsi_rcv.ipl = (12),
  .dsi_rcv.irq = VECTOR_NUMBER_MIPIDSI_RCV,

  .dsi_ferr.ipl = (12),
  .dsi_ferr.irq = VECTOR_NUMBER_MIPIDSI_FERR,

  .dsi_ppi.ipl = (12),
  .dsi_ppi.irq = VECTOR_NUMBER_MIPIDSI_PPI,

  .dsi_rxie = R_DSILINK_RXIER_BTAREND_Msk | R_DSILINK_RXIER_LRXHTO_Msk | R_DSILINK_RXIER_TATO_Msk
          | R_DSILINK_RXIER_RXRESP_Msk | R_DSILINK_RXIER_RXEOTP_Msk | R_DSILINK_RXIER_RXTE_Msk
          | R_DSILINK_RXIER_RXACK_Msk | R_DSILINK_RXIER_EXTEDET_Msk | R_DSILINK_RXIER_MLFERR_Msk
          | R_DSILINK_RXIER_ECCERRM_Msk | R_DSILINK_RXIER_UNEXERR_Msk | R_DSILINK_RXIER_WCERR_Msk
          | R_DSILINK_RXIER_CRCERR_Msk | R_DSILINK_RXIER_IBERR_Msk | R_DSILINK_RXIER_RXOVFERR_Msk
          | R_DSILINK_RXIER_PRTOERR_Msk | R_DSILINK_RXIER_NORESERR_Msk | R_DSILINK_RXIER_RSIZEERR_Msk
          | R_DSILINK_RXIER_ECCERRS_Msk | R_DSILINK_RXIER_RXAKE_Msk | 0x0,
  .dsi_ferrie = R_DSILINK_FERRIER_HTXTO_Msk | R_DSILINK_FERRIER_LRXHTO_Msk | R_DSILINK_FERRIER_TATO_Msk
          | R_DSILINK_FERRIER_ESCENT_Msk | R_DSILINK_FERRIER_SYNCESC_Msk | R_DSILINK_FERRIER_CTRL_Msk
          | R_DSILINK_FERRIER_CLP0_Msk | R_DSILINK_FERRIER_CLP1_Msk | 0x0,
  .dsi_plie = 0x0, .dsi_vmie = R_DSILINK_VMIER_VBUFUDF_Msk | R_DSILINK_VMIER_VBUFOVF_Msk | 0x0, .dsi_sqch0ie =
          R_DSILINK_SQCH0IER_AACTFIN_Msk | R_DSILINK_SQCH0IER_ADESFIN_Msk | R_DSILINK_SQCH0IER_TXIBERR_Msk
                  | R_DSILINK_SQCH0IER_RXFERR_Msk | R_DSILINK_SQCH0IER_RXFAIL_Msk | R_DSILINK_SQCH0IER_RXPFAIL_Msk
                  | R_DSILINK_SQCH0IER_RXCORERR_Msk | R_DSILINK_SQCH0IER_RXAKE_Msk | 0x0,
  .dsi_sqch1ie = R_DSILINK_SQCH1IER_AACTFIN_Msk | R_DSILINK_SQCH1IER_ADESFIN_Msk | R_DSILINK_SQCH1IER_SIZEERR_Msk
          | R_DSILINK_SQCH1IER_TXIBERR_Msk | R_DSILINK_SQCH1IER_RXFERR_Msk | R_DSILINK_SQCH1IER_RXFAIL_Msk
          | R_DSILINK_SQCH1IER_RXPFAIL_Msk | R_DSILINK_SQCH1IER_RXCORERR_Msk | R_DSILINK_SQCH1IER_RXAKE_Msk | 0x0, };

const mipi_dsi_cfg_t g_mipi_dsi0_cfg =
        { .p_mipi_phy_instance = &g_mipi_phy0,

          .p_timing = &g_mipi_dsi0_timing,

          .sync_pulse = (0),
          .data_type = MIPI_DSI_VIDEO_DATA_24RGB_PIXEL_STREAM,
          .virtual_channel_id = 0,

          .vertical_active_lines = 854,
          .vertical_sync_lines = 3,
          .vertical_back_porch = (20 - 3),
          .vertical_front_porch = (894 - 854 - 20 - 3),
          .vertical_sync_polarity = (DISPLAY_SIGNAL_POLARITY_LOACTIVE != DISPLAY_SIGNAL_POLARITY_HIACTIVE),

          .horizontal_active_lines = 480,
          .horizontal_sync_lines = 2,
          .horizontal_back_porch = (5 - 2),
          .horizontal_front_porch = (559 - 480 - 5 - 2),
          .horizontal_sync_polarity = (DISPLAY_SIGNAL_POLARITY_LOACTIVE != DISPLAY_SIGNAL_POLARITY_HIACTIVE),

          .video_mode_delay = 462 /* This value was calculated by FSP. An override is available but not recommended for most users */,

          .hsa_no_lp = ((0x0) & R_DSILINK_VMSET0R_HSANOLP_Msk),
          .hbp_no_lp = ((0x0) & R_DSILINK_VMSET0R_HBPNOLP_Msk),
          .hfp_no_lp = ((0x0) & R_DSILINK_VMSET0R_HFPNOLP_Msk),

          .num_lanes = 2,
          .ulps_wakeup_period = 97,
          .continuous_clock = (1),

          .hs_tx_timeout = 0,
          .lp_rx_timeout = 0,
          .turnaround_timeout = 0,
          .bta_timeout = 0,
          .lprw_timeout = (0 << R_DSILINK_PRESPTOLPSETR_LPRTO_Pos) | 0,
          .hsrw_timeout = (0 << R_DSILINK_PRESPTOHSSETR_HSRTO_Pos) | 0,

          .max_return_packet_size = 1,
          .ecc_enable = (1),
          .crc_check_mask = (mipi_dsi_vc_t) (0x0),
          .scramble_enable = (0),
          .tearing_detect = (0),
          .eotp_enable = (1),

          .p_extend = &g_mipi_dsi0_extended_cfg,
          .p_callback = mipi_dsi0_callback,
          .p_context = NULL, };

/* Instance structure to use this module. */
const mipi_dsi_instance_t g_mipi_dsi0 =
{ .p_ctrl = &g_mipi_dsi0_ctrl, .p_cfg = &g_mipi_dsi0_cfg, .p_api = &g_mipi_dsi };
/** Display framebuffer */
#if GLCDC_CFG_LAYER_1_ENABLE
        uint8_t fb_background[2][DISPLAY_BUFFER_STRIDE_BYTES_INPUT0 * DISPLAY_VSIZE_INPUT0] BSP_ALIGN_VARIABLE(64) BSP_PLACE_IN_SECTION(".ospi_device_0_no_load");
        #else
/** Graphics Layer 1 is specified not to be used when starting */
#endif
#if GLCDC_CFG_LAYER_2_ENABLE
        uint8_t fb_foreground[1][DISPLAY_BUFFER_STRIDE_BYTES_INPUT1 * DISPLAY_VSIZE_INPUT1] BSP_ALIGN_VARIABLE(64) BSP_PLACE_IN_SECTION(".ospi_device_0_no_load");
        #else
/** Graphics Layer 2 is specified not to be used when starting */
#endif

#if GLCDC_CFG_CLUT_ENABLE
        /** Display CLUT buffer to be used for updating CLUT */
        static uint32_t CLUT_buffer[256];

        /** Display CLUT configuration(only used if using CLUT format) */
        display_clut_cfg_t g_display0_clut_cfg_glcdc =
        {
            .p_base              = (uint32_t *)CLUT_buffer,
            .start               = 0,   /* User have to update this setting when using */
            .size                = 256  /* User have to update this setting when using */
        };
        #else
/** CLUT is specified not to be used */
#endif

#if (false)
         #define GLCDC_CFG_CORRECTION_GAMMA_TABLE_CONST   const
         #define GLCDC_CFG_CORRECTION_GAMMA_TABLE_CAST    (uint16_t *)
         #define GLCDC_CFG_CORRECTION_GAMMA_CFG_CAST      (display_gamma_correction_t *)
        #else
#define GLCDC_CFG_CORRECTION_GAMMA_TABLE_CONST
#define GLCDC_CFG_CORRECTION_GAMMA_TABLE_CAST
#define GLCDC_CFG_CORRECTION_GAMMA_CFG_CAST
#endif

#if ((GLCDC_CFG_CORRECTION_GAMMA_ENABLE_R | GLCDC_CFG_CORRECTION_GAMMA_ENABLE_G | GLCDC_CFG_CORRECTION_GAMMA_ENABLE_B) && GLCDC_CFG_COLOR_CORRECTION_ENABLE)
        /** Gamma correction tables */
        #if GLCDC_CFG_CORRECTION_GAMMA_ENABLE_R
        static GLCDC_CFG_CORRECTION_GAMMA_TABLE_CONST uint16_t glcdc_gamma_r_gain[DISPLAY_GAMMA_CURVE_ELEMENT_NUM] = {1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024};
        static GLCDC_CFG_CORRECTION_GAMMA_TABLE_CONST uint16_t glcdc_gamma_r_threshold[DISPLAY_GAMMA_CURVE_ELEMENT_NUM] = {0, 64, 128, 192, 256, 320, 384, 448, 512, 576, 640, 704, 768, 832, 896, 960};
        #endif
        #if GLCDC_CFG_CORRECTION_GAMMA_ENABLE_G
        static GLCDC_CFG_CORRECTION_GAMMA_TABLE_CONST uint16_t glcdc_gamma_g_gain[DISPLAY_GAMMA_CURVE_ELEMENT_NUM] = {1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024};
        static GLCDC_CFG_CORRECTION_GAMMA_TABLE_CONST uint16_t glcdc_gamma_g_threshold[DISPLAY_GAMMA_CURVE_ELEMENT_NUM] = {0, 64, 128, 192, 256, 320, 384, 448, 512, 576, 640, 704, 768, 832, 896, 960};
        #endif
        #if GLCDC_CFG_CORRECTION_GAMMA_ENABLE_B
        static GLCDC_CFG_CORRECTION_GAMMA_TABLE_CONST uint16_t glcdc_gamma_b_gain[DISPLAY_GAMMA_CURVE_ELEMENT_NUM] = {1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024, 1024};
        static GLCDC_CFG_CORRECTION_GAMMA_TABLE_CONST uint16_t glcdc_gamma_b_threshold[DISPLAY_GAMMA_CURVE_ELEMENT_NUM] = {0, 64, 128, 192, 256, 320, 384, 448, 512, 576, 640, 704, 768, 832, 896, 960};
        #endif
        GLCDC_CFG_CORRECTION_GAMMA_TABLE_CONST display_gamma_correction_t g_display0_gamma_cfg =
        {
            .r =
            {
                .enable      = GLCDC_CFG_CORRECTION_GAMMA_ENABLE_R,
        #if GLCDC_CFG_CORRECTION_GAMMA_ENABLE_R
                .gain        = GLCDC_CFG_CORRECTION_GAMMA_TABLE_CAST glcdc_gamma_r_gain,
                .threshold   = GLCDC_CFG_CORRECTION_GAMMA_TABLE_CAST glcdc_gamma_r_threshold
        #else
                .gain        = NULL,
                .threshold   = NULL
        #endif
            },
            .g =
            {
                .enable      = GLCDC_CFG_CORRECTION_GAMMA_ENABLE_G,
        #if GLCDC_CFG_CORRECTION_GAMMA_ENABLE_G
                .gain        = GLCDC_CFG_CORRECTION_GAMMA_TABLE_CAST glcdc_gamma_g_gain,
                .threshold   = GLCDC_CFG_CORRECTION_GAMMA_TABLE_CAST glcdc_gamma_g_threshold
        #else
                .gain        = NULL,
                .threshold   = NULL
        #endif
            },
            .b =
            {
                .enable      = GLCDC_CFG_CORRECTION_GAMMA_ENABLE_B,
        #if GLCDC_CFG_CORRECTION_GAMMA_ENABLE_B
                .gain        = GLCDC_CFG_CORRECTION_GAMMA_TABLE_CAST glcdc_gamma_b_gain,
                .threshold   = GLCDC_CFG_CORRECTION_GAMMA_TABLE_CAST glcdc_gamma_b_threshold
        #else
                .gain        = NULL,
                .threshold   = NULL
        #endif
            }
        };
        #endif

#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED != g_mipi_dsi0)
const mipi_dsi_instance_t g_mipi_dsi0;
#endif
/** Display device extended configuration */
const glcdc_extended_cfg_t g_display0_extend_cfg =
{ .tcon_hsync = GLCDC_TCON_PIN_1,
  .tcon_vsync = GLCDC_TCON_PIN_0,
  .tcon_de = GLCDC_TCON_PIN_2,
  .correction_proc_order = GLCDC_CORRECTION_PROC_ORDER_BRIGHTNESS_CONTRAST2GAMMA,
  .clksrc = GLCDC_CLK_SRC_INTERNAL,
  .clock_div_ratio = GLCDC_PANEL_CLK_DIVISOR_16,
  .dithering_mode = GLCDC_DITHERING_MODE_TRUNCATE,
  .dithering_pattern_A = GLCDC_DITHERING_PATTERN_11,
  .dithering_pattern_B = GLCDC_DITHERING_PATTERN_11,
  .dithering_pattern_C = GLCDC_DITHERING_PATTERN_11,
  .dithering_pattern_D = GLCDC_DITHERING_PATTERN_11,
#if (RA_NOT_DEFINED != g_mipi_dsi0)
  .phy_layer = (void*) &g_mipi_dsi0
#else
            .phy_layer             = NULL
        #endif
        };
#undef RA_NOT_DEFINED

/** Display control block instance */
glcdc_instance_ctrl_t g_display0_ctrl;

/** Display interface configuration */
const display_cfg_t g_display0_cfg =
        {
        /** Input1(Graphics1 layer) configuration */
        .input[0] =
        {
#if GLCDC_CFG_LAYER_1_ENABLE
                .p_base              = (uint32_t *)&fb_background[0],
                #else
          .p_base = NULL,
#endif
          .hsize = DISPLAY_HSIZE_INPUT0,
          .vsize = DISPLAY_VSIZE_INPUT0, .hstride = DISPLAY_BUFFER_STRIDE_PIXELS_INPUT0, .format =
                  DISPLAY_IN_FORMAT_16BITS_RGB565,
          .line_descending_enable = false, .lines_repeat_enable = false, .lines_repeat_times = 0 },

          /** Input2(Graphics2 layer) configuration */
          .input[1] =
          {
#if GLCDC_CFG_LAYER_2_ENABLE
                .p_base              = (uint32_t *)&fb_foreground[0],
                #else
            .p_base = NULL,
#endif
            .hsize = DISPLAY_HSIZE_INPUT1,
            .vsize = DISPLAY_VSIZE_INPUT1, .hstride = DISPLAY_BUFFER_STRIDE_PIXELS_INPUT1, .format =
                    DISPLAY_IN_FORMAT_32BITS_RGB888,
            .line_descending_enable = false, .lines_repeat_enable = false, .lines_repeat_times = 0 },

          /** Input1(Graphics1 layer) layer configuration */
          .layer[0] =
          { .coordinate =
          { .x = 0, .y = 0 },
            .fade_control = DISPLAY_FADE_CONTROL_NONE, .fade_speed = 0 },

          /** Input2(Graphics2 layer) layer configuration */
          .layer[1] =
          { .coordinate =
          { .x = 0, .y = 0 },
            .fade_control = DISPLAY_FADE_CONTROL_NONE, .fade_speed = 0 },

          /** Output configuration */
          .output =
                  { .htiming =
                  { .total_cyc = 559, .display_cyc = 480, .back_porch = 5, .sync_width = 2, .sync_polarity =
                            DISPLAY_SIGNAL_POLARITY_LOACTIVE },
                    .vtiming =
                    { .total_cyc = 894, .display_cyc = 854, .back_porch = 20, .sync_width = 3, .sync_polarity =
                              DISPLAY_SIGNAL_POLARITY_LOACTIVE },
                    .format = DISPLAY_OUT_FORMAT_24BITS_RGB888, .endian = DISPLAY_ENDIAN_LITTLE, .color_order =
                            DISPLAY_COLOR_ORDER_RGB,
                    .data_enable_polarity = DISPLAY_SIGNAL_POLARITY_HIACTIVE, .sync_edge =
                            DISPLAY_SIGNAL_SYNC_EDGE_FALLING,
                    .bg_color =
                    { .byte =
                    { .a = 255, .r = 0, .g = 0, .b = 0 } },
#if (GLCDC_CFG_COLOR_CORRECTION_ENABLE)
                .brightness =
                {
                    .enable          = false,
                    .r               = 512,
                    .g               = 512,
                    .b               = 512
                },
                .contrast =
                {
                    .enable          = false,
                    .r               = 128,
                    .g               = 128,
                    .b               = 128
                },
#if (GLCDC_CFG_CORRECTION_GAMMA_ENABLE_R | GLCDC_CFG_CORRECTION_GAMMA_ENABLE_G | GLCDC_CFG_CORRECTION_GAMMA_ENABLE_B)
 #if false
                .p_gamma_correction  = GLCDC_CFG_CORRECTION_GAMMA_CFG_CAST (&g_display0_gamma_cfg),
 #else
                .p_gamma_correction  = &g_display0_gamma_cfg,
 #endif
#else
                .p_gamma_correction  = NULL,
#endif
#endif
                    .dithering_on = false },

          /** Display device callback function pointer */
          .p_callback = glcdc_callback,
          .p_context = NULL,

          /** Display device extended configuration */
          .p_extend = (void*) (&g_display0_extend_cfg),

          .line_detect_ipl = (12),
          .underflow_1_ipl = (BSP_IRQ_DISABLED), .underflow_2_ipl = (BSP_IRQ_DISABLED),

#if defined(VECTOR_NUMBER_GLCDC_LINE_DETECT)
            .line_detect_irq        = VECTOR_NUMBER_GLCDC_LINE_DETECT,
#else
          .line_detect_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GLCDC_UNDERFLOW_1)
            .underflow_1_irq        = VECTOR_NUMBER_GLCDC_UNDERFLOW_1,
#else
          .underflow_1_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GLCDC_UNDERFLOW_2)
            .underflow_2_irq        = VECTOR_NUMBER_GLCDC_UNDERFLOW_2,
#else
          .underflow_2_irq = FSP_INVALID_VECTOR,
#endif
        };

#if GLCDC_CFG_LAYER_1_ENABLE
        /** Display on GLCDC run-time configuration(for the graphics1 layer) */
        display_runtime_cfg_t g_display0_runtime_cfg_bg =
        {
            .input =
            {
                #if (true)
                .p_base              = (uint32_t *)&fb_background[0],
                #else
                .p_base              = NULL,
                #endif
                .hsize               = DISPLAY_HSIZE_INPUT0,
                .vsize               = DISPLAY_VSIZE_INPUT0,
                .hstride             = DISPLAY_BUFFER_STRIDE_PIXELS_INPUT0,
                .format              = DISPLAY_IN_FORMAT_16BITS_RGB565,
                .line_descending_enable = false,
                .lines_repeat_enable = false,
                .lines_repeat_times  = 0
            },
            .layer =
            {
                .coordinate = {
                        .x           = 0,
                        .y           = 0
                },
                .fade_control        = DISPLAY_FADE_CONTROL_NONE,
                .fade_speed          = 0
            }
        };
#endif
#if GLCDC_CFG_LAYER_2_ENABLE
        /** Display on GLCDC run-time configuration(for the graphics2 layer) */
        display_runtime_cfg_t g_display0_runtime_cfg_fg =
        {
            .input =
            {
                #if (false)
                .p_base              = (uint32_t *)&fb_foreground[0],
                #else
                .p_base              = NULL,
                #endif
                .hsize               = DISPLAY_HSIZE_INPUT1,
                .vsize               = DISPLAY_VSIZE_INPUT1,
                .hstride             = DISPLAY_BUFFER_STRIDE_PIXELS_INPUT1,
                .format              = DISPLAY_IN_FORMAT_32BITS_RGB888,
                .line_descending_enable = false,
                .lines_repeat_enable = false,
                .lines_repeat_times  = 0
             },
            .layer =
            {
                .coordinate = {
                        .x           = 0,
                        .y           = 0
                },
                .fade_control        = DISPLAY_FADE_CONTROL_NONE,
                .fade_speed          = 0
            }
        };
#endif

/* Instance structure to use this module. */
const display_instance_t g_display0 =
{ .p_ctrl = &g_display0_ctrl, .p_cfg = (display_cfg_t*) &g_display0_cfg, .p_api = (display_api_t*) &g_display_on_glcdc };
ioport_instance_ctrl_t g_ioport_ctrl;
const ioport_instance_t g_ioport =
{ .p_api = &g_ioport_on_ioport, .p_ctrl = &g_ioport_ctrl, .p_cfg = &g_bsp_pin_cfg, };
SemaphoreHandle_t g_reset_binary_semaphore;
#if 1
StaticSemaphore_t g_reset_binary_semaphore_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
SemaphoreHandle_t g_irq_binary_semaphore;
#if 1
StaticSemaphore_t g_irq_binary_semaphore_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
SemaphoreHandle_t g_iic_binary_semaphore;
#if 1
StaticSemaphore_t g_iic_binary_semaphore_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
EventGroupHandle_t g_i2c_event_group;
#if 1
StaticEventGroup_t g_i2c_event_group_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
SemaphoreHandle_t g_serial_binary_semaphore;
#if 1
StaticSemaphore_t g_serial_binary_semaphore_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
SemaphoreHandle_t _SemaphoreVsync;
#if 1
StaticSemaphore_t _SemaphoreVsync_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
SemaphoreHandle_t glcdc_update_complete;
#if 1
StaticSemaphore_t glcdc_update_complete_memory;
#endif
void rtos_startup_err_callback(void *p_instance, void *p_data);
void g_common_init(void)
{
    g_reset_binary_semaphore =
#if 1
            xSemaphoreCreateBinaryStatic (&g_reset_binary_semaphore_memory);
#else
                xSemaphoreCreateBinary();
                #endif
    if (NULL == g_reset_binary_semaphore)
    {
        rtos_startup_err_callback (g_reset_binary_semaphore, 0);
    }
    g_irq_binary_semaphore =
#if 1
            xSemaphoreCreateBinaryStatic (&g_irq_binary_semaphore_memory);
#else
                xSemaphoreCreateBinary();
                #endif
    if (NULL == g_irq_binary_semaphore)
    {
        rtos_startup_err_callback (g_irq_binary_semaphore, 0);
    }
    g_iic_binary_semaphore =
#if 1
            xSemaphoreCreateBinaryStatic (&g_iic_binary_semaphore_memory);
#else
                xSemaphoreCreateBinary();
                #endif
    if (NULL == g_iic_binary_semaphore)
    {
        rtos_startup_err_callback (g_iic_binary_semaphore, 0);
    }
    g_i2c_event_group =
#if 1
            xEventGroupCreateStatic (&g_i2c_event_group_memory);
#else
                xEventGroupCreate();
                #endif
    if (NULL == g_i2c_event_group)
    {
        rtos_startup_err_callback (g_i2c_event_group, 0);
    }
    g_serial_binary_semaphore =
#if 1
            xSemaphoreCreateBinaryStatic (&g_serial_binary_semaphore_memory);
#else
                xSemaphoreCreateBinary();
                #endif
    if (NULL == g_serial_binary_semaphore)
    {
        rtos_startup_err_callback (g_serial_binary_semaphore, 0);
    }
    _SemaphoreVsync =
#if 1
            xSemaphoreCreateBinaryStatic (&_SemaphoreVsync_memory);
#else
                xSemaphoreCreateBinary();
                #endif
    if (NULL == _SemaphoreVsync)
    {
        rtos_startup_err_callback (_SemaphoreVsync, 0);
    }
    glcdc_update_complete =
#if 1
            xSemaphoreCreateBinaryStatic (&glcdc_update_complete_memory);
#else
                xSemaphoreCreateBinary();
                #endif
    if (NULL == glcdc_update_complete)
    {
        rtos_startup_err_callback (glcdc_update_complete, 0);
    }
}
