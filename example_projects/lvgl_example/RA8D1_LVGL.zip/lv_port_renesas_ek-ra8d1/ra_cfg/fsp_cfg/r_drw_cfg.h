/* generated configuration header file - do not edit */
#ifndef R_DRW_CFG_H_
#define R_DRW_CFG_H_
#ifdef __cplusplus
            extern "C" {
            #endif

#define DRW_CFG_USE_DLIST_INDIRECT   ((1))
#ifdef VECTOR_NUMBER_DRW_INT
            #define DRW_CFG_INT_IRQ              (VECTOR_NUMBER_DRW_INT)
            #endif
#define DRW_CFG_CUSTOM_MALLOC        ((0))

#ifdef __cplusplus
            }
            #endif
#endif /* R_DRW_CFG_H_ */
